# 毕业设计-图像风格转换系统的源码
# python版本：2.7.14
# 运行方法：命令行cd至当前文件夹，```$ python main.py ``` 即可成功运行，看到图形界面。
# 依赖库：tensorflow==1.9.0、numpy==1.16.2、cv2(aircv)==1.4.6、pillow==4.2.1、tkinter。
# 图像风格转移算法参考的论文：《A Neural Algorithm of Artistic Style》（1508.06576）

